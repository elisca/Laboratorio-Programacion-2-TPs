﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace FormAstros
{
    public partial class FormSistemaSolar : Form
    {
        static List<Astro> planetas = SistemaSolar.Planetas;

        public FormSistemaSolar()
        {
            InitializeComponent();
        }

        public bool Planeta_ValidarDatosCompletados()
        {
            int auxOrbitaPlaneta = 0;

            if (this.txtNombrePlaneta.TextLength > 0 && int.TryParse(this.txtOrbitaPlaneta.Text, out auxOrbitaPlaneta) && this.numRotacion.Value > 0 && this.numSatelite.Value >= 0 && this.cmbTipo.SelectedIndex >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool Satelite_ValidarDatosCompletados()
        {
            if (this.cmbPlanetas.SelectedIndex >= 0 && this.txtNombreSatelite.TextLength >= 0 && this.numOrbitaSatelite.Value > 0 && this.numRotacionSatelite.Value > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private void btnAgregarPlaneta_Click(object sender, EventArgs e)
        {
            if (Planeta_ValidarDatosCompletados())
            {
                Planeta newPlaneta = new Planeta(int.Parse(this.txtOrbitaPlaneta.Text), (int)(this.numRotacion.Value), this.txtNombrePlaneta.Text);
                FormSistemaSolar.planetas.Add(newPlaneta);
                this.cmbPlanetas.Items.Add((string)newPlaneta);
                MessageBox.Show("Planeta agregado correctamente.");
            }
            else
            {
                MessageBox.Show("Error al intentar agregar un planeta.");
            }
        }

        private void btnAgregarSatelite_Click(object sender, EventArgs e)
        {
            bool planetaEncontrado = false;
            if (Satelite_ValidarDatosCompletados())
            {
                Satelite auxSatelite = new Satelite((int)this.numOrbitaSatelite.Value, (int)this.numRotacionSatelite.Value, txtNombreSatelite.Text);

                foreach (Planeta auxPlaneta in FormSistemaSolar.planetas)
                {
                    if ((string)auxPlaneta == this.cmbPlanetas.SelectedItem.ToString())
                    {
                        if (auxPlaneta + auxSatelite)
                        {
                            planetaEncontrado = true;
                            MessageBox.Show("Satélite agregado correctamente.");
                            break;
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("No se pudo agregar este satélite.");
            }
        }
    }
}
