﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class SistemaSolar
    {
        static List<Astro> planetas;

        public static List<Astro> Planetas
        {
            get
            {
                return SistemaSolar.planetas;
            }
        }

        public static string MostrarInformacionAstros()
        {
            StringBuilder sb = new StringBuilder();

            foreach (Planeta auxPlaneta in SistemaSolar.Planetas)
            {
                sb.AppendFormat("{0}", auxPlaneta.ToString());
                foreach (Satelite auxSatelite in auxPlaneta.Satelites)
                {
                    sb.AppendFormat(" ->{0}", auxSatelite.ToString());
                }
            }

            return sb.ToString();
        }

        static SistemaSolar()
        {
            planetas = new List<Astro>();
        }
    }
}
