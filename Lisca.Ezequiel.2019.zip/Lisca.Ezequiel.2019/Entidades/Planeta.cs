﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Planeta :Astro
    {
        int cantSatelites;
        Tipo tipo;
        List<Astro> satelites;

        public List<Astro> Satelites
        {
            get
            {
                return this.satelites;
            }
        }

        public static bool operator !=(Planeta planeta, Planeta planeta2)
        {
            return !(planeta == planeta2);
        }

        public static bool operator !=(Planeta planeta, Satelite satelite)
        {
            return !(planeta == satelite);
        }

        public static bool operator +(Planeta planeta, Satelite satelite)
        {
            if (satelite != null)
            {
                planeta.satelites.Add(satelite);
                planeta.cantSatelites++;
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool operator ==(Planeta planeta, Planeta planeta2)
        {
            return (planeta.nombre == planeta2.nombre);
        }

        public static bool operator ==(Planeta planeta, Satelite satelite)
        {
            foreach (Satelite auxSatelite in planeta.satelites)
            {
                if (auxSatelite.Nombre == satelite.Nombre)
                {
                    return true;
                }
            }
            return false;
        }

        public override string Orbitar()
        {
            return "Orbita el planeta: " + this.nombre;
        }

        public Planeta(int duraOrbita, int duraRot, string nombre, int cantSatelites, Tipo tipo):this(duraOrbita, duraRot, nombre)
        {
            this.cantSatelites = cantSatelites;
            this.tipo = tipo;
        }

        public Planeta(int duraOrbita, int duraRot, string nombre):base(duraOrbita, duraRot, nombre)
        {
            this.satelites = new List<Astro>();
        }

        public override string Rotar()
        {
            return base.Rotar();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Tipo: {0} - Astro: {1} - Cant. Satélites: {2} - Nombre: {3} - {4}\n", this.tipo, this.GetType().ToString(), this.cantSatelites, (string)this, base.Mostrar());
            return sb.ToString();
        }
    }
}
