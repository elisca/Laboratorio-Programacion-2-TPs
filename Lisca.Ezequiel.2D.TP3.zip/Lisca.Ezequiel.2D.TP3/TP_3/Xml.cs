﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP_3
{
    public class Xml<T>
    {
        public bool Guardar(string archivo, T datos)
        {
            return false;
        }

        public bool Leer(string archivo, out T datos)
        {
            return false;
        }
    }
}
