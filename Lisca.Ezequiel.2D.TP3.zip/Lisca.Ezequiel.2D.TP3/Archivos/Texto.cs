﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Archivos
{
    public class Texto
    {
        public bool Guardar(string archivo, string datos)
        {
            return false;
        }

        public bool Leer(string archivo, out string datos)
        {
            return false;
        }
    }
}
